from scapy.all import sniff

def packet_callback(packet):
    print(packet.summary())

# Start sniffing on your default network interface
sniff(prn=packet_callback, count=100)
